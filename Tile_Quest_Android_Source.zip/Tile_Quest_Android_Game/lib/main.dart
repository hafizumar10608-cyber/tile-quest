
import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const TileQuestApp());

class TileQuestApp extends StatelessWidget {
  const TileQuestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tile Quest',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0A1220),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFFC857),
          secondary: Color(0xFF55D6BE),
          surface: Color(0xFF172438),
        ),
      ),
      home: const PuzzleScreen(),
    );
  }
}

class PuzzleScreen extends StatefulWidget {
  const PuzzleScreen({super.key});
  @override
  State<PuzzleScreen> createState() => _PuzzleScreenState();
}

class _PuzzleScreenState extends State<PuzzleScreen> {
  final Random random = Random();
  int level = 1;
  int moves = 0;
  int coins = 0;
  late int size;
  late List<int> tiles;
  bool solved = false;

  @override
  void initState() {
    super.initState();
    _newLevel();
  }

  void _newLevel() {
    size = level < 6 ? 3 : (level < 16 ? 4 : 5);
    tiles = List<int>.generate(size * size, (i) => (i + 1) % (size * size));
    // Shuffle by making legal moves from the solved state, preserving solvability.
    int previousBlank = -1;
    for (int i = 0; i < 90 + level * 8; i++) {
      final blank = tiles.indexOf(0);
      final options = _neighbors(blank)
          .where((p) => p != previousBlank)
          .toList();
      final pick = options[random.nextInt(options.length)];
      previousBlank = blank;
      tiles[blank] = tiles[pick];
      tiles[pick] = 0;
    }
    if (_isSolved()) {
      final blank = tiles.indexOf(0);
      final p = _neighbors(blank).first;
      tiles[blank] = tiles[p];
      tiles[p] = 0;
    }
    moves = 0;
    solved = false;
    setState(() {});
  }

  List<int> _neighbors(int index) {
    final row = index ~/ size;
    final col = index % size;
    final result = <int>[];
    if (row > 0) result.add(index - size);
    if (row < size - 1) result.add(index + size);
    if (col > 0) result.add(index - 1);
    if (col < size - 1) result.add(index + 1);
    return result;
  }

  bool _isSolved() {
    for (int i = 0; i < tiles.length - 1; i++) {
      if (tiles[i] != i + 1) return false;
    }
    return tiles.last == 0;
  }

  void _tapTile(int index) {
    if (solved || tiles[index] == 0) return;
    final blank = tiles.indexOf(0);
    if (!_neighbors(blank).contains(index)) return;
    setState(() {
      tiles[blank] = tiles[index];
      tiles[index] = 0;
      moves++;
      if (_isSolved()) {
        solved = true;
        coins += max(10, 60 - moves ~/ 2);
      }
    });
  }

  void _nextLevel() {
    setState(() => level++);
    _newLevel();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        height: 46, width: 46,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFC857),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: const Icon(Icons.extension_rounded,
                            color: Color(0xFF172438), size: 28),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('TILE QUEST',
                              style: TextStyle(fontSize: 20,
                                fontWeight: FontWeight.w900, letterSpacing: 2)),
                            Text('SLIDE • SOLVE • SHINE',
                              style: TextStyle(fontSize: 10,
                                color: Color(0xFF9FB0C7), letterSpacing: 1.5)),
                          ],
                        ),
                      ),
                      _stat(Icons.monetization_on_rounded, '$coins'),
                    ],
                  ),
                  const SizedBox(height: 26),
                  Row(
                    children: [
                      Expanded(child: _infoCard('LEVEL', '$level')),
                      const SizedBox(width: 10),
                      Expanded(child: _infoCard('MOVES', '$moves')),
                      const SizedBox(width: 10),
                      Expanded(child: _infoCard('GRID', '${size}×$size')),
                    ],
                  ),
                  const Spacer(),
                  const Text('Put the numbers in order',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 7),
                  const Text('Tap a tile next to the empty space to slide it.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFF9FB0C7), fontSize: 13)),
                  const SizedBox(height: 22),
                  AspectRatio(
                    aspectRatio: 1,
                    child: Container(
                      padding: const EdgeInsets.all(9),
                      decoration: BoxDecoration(
                        color: const Color(0xFF172438),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFF263A55)),
                      ),
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: tiles.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: size,
                          crossAxisSpacing: 7,
                          mainAxisSpacing: 7,
                        ),
                        itemBuilder: (context, index) {
                          final value = tiles[index];
                          return Material(
                            color: value == 0
                                ? const Color(0xFF0A1220)
                                : const Color(0xFF243A56),
                            borderRadius: BorderRadius.circular(14),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(14),
                              onTap: () => _tapTile(index),
                              child: Center(
                                child: value == 0
                                    ? const SizedBox.shrink()
                                    : Text('$value',
                                      style: TextStyle(
                                        fontSize: size == 3 ? 30 : (size == 4 ? 24 : 19),
                                        fontWeight: FontWeight.w800,
                                        color: const Color(0xFFFFC857))),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  const Spacer(),
                  if (solved)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF173D3A),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: const Color(0xFF55D6BE)),
                      ),
                      child: Column(
                        children: [
                          const Text('LEVEL COMPLETE!',
                            style: TextStyle(fontSize: 19,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF55D6BE))),
                          const SizedBox(height: 4),
                          Text('You earned ${max(10, 60 - moves ~/ 2)} coins.',
                            style: const TextStyle(color: Colors.white70)),
                          const SizedBox(height: 10),
                          SizedBox(width: double.infinity,
                            child: ElevatedButton(
                              onPressed: _nextLevel,
                              child: const Text('NEXT LEVEL'),
                            )),
                        ],
                      ),
                    )
                  else
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _newLevel,
                            icon: const Icon(Icons.shuffle_rounded),
                            label: const Text('SHUFFLE'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFFFFC857),
                              side: const BorderSide(color: Color(0xFF52647D)),
                              padding: const EdgeInsets.symmetric(vertical: 15),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => showDialog<void>(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: const Text('How to play'),
                                content: const Text(
                                  'Slide one tile at a time into the empty space. '
                                  'Arrange the numbers from 1 to the last number, '
                                  'with the empty space in the bottom-right corner.'
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: const Text('GOT IT'),
                                  ),
                                ],
                              ),
                            ),
                            icon: const Icon(Icons.help_outline_rounded),
                            label: const Text('HOW TO PLAY'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFFFC857),
                              foregroundColor: const Color(0xFF172438),
                              padding: const EdgeInsets.symmetric(vertical: 15),
                            ),
                          ),
                        ),
                      ],
                    ),
                  const SizedBox(height: 10),
                  const Text('OFFLINE PUZZLE • NO ACCOUNT REQUIRED',
                    style: TextStyle(fontSize: 9, color: Color(0xFF70839D),
                      letterSpacing: 1.2)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _stat(IconData icon, String value) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
    decoration: BoxDecoration(
      color: const Color(0xFF172438),
      borderRadius: BorderRadius.circular(13),
    ),
    child: Row(children: [
      Icon(icon, color: const Color(0xFFFFC857), size: 18),
      const SizedBox(width: 5),
      Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
    ]),
  );

  Widget _infoCard(String label, String value) => Container(
    padding: const EdgeInsets.symmetric(vertical: 12),
    decoration: BoxDecoration(
      color: const Color(0xFF172438),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Column(children: [
      Text(label, style: const TextStyle(fontSize: 9,
        color: Color(0xFF9FB0C7), letterSpacing: 1.3)),
      const SizedBox(height: 4),
      Text(value, style: const TextStyle(fontSize: 19,
        fontWeight: FontWeight.w800, color: Color(0xFFFFC857))),
    ]),
  );
}
