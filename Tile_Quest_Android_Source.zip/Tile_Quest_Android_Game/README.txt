TILE QUEST — ANDROID PUZZLE GAME

This is the Flutter source project for Tile Quest, an offline sliding-number puzzle.
It includes a custom app icon and a GitHub Actions cloud-build workflow.

GAME FEATURES
- Sliding number puzzle with 3x3, 4x4 and 5x5 levels
- Solvable shuffle (the board is shuffled using legal moves)
- Move counter and in-game score coins (coins have no cash value)
- Level progression
- How-to-play help
- Offline play; no account or network access required during gameplay

IMPORTANT: This ZIP is source code, not a prebuilt APK/AAB. It has not yet been
built and tested on a physical Android device. A Play Store release also needs
proper release signing, device testing, store listing, privacy/data declarations,
content rating, and Google review. Do not claim the app has been tested until it is.

CLOUD BUILD (MOBILE-FRIENDLY)
1. Create a GitHub repository named tile-quest.
2. Extract this ZIP on your phone.
3. Upload the CONTENTS of the Tile_Quest_Android_Game folder to the repository
   root. Include the hidden .github/workflows/android.yml file/folder.
4. Open the repository's Actions tab and enable Actions if prompted.
5. Run "Build Tile Quest for Android" (or push a commit to main).
6. When it finishes, open the workflow run and download the artifact
   "tile-quest-android-builds". It contains an APK and an AAB build.

PLAY STORE SIGNING
The cloud workflow creates a build for testing. Before public release, configure
an upload keystore and release signing in a secure way, then rebuild the AAB.
Never share your keystore or passwords. Google Play Console may also require
account verification, testing, and other declarations. Follow the current
Play Console instructions and involve a parent/guardian where required.

PACKAGE ID: com.northstar.tile_quest
APP NAME: Tile Quest
CATEGORY: Puzzle
